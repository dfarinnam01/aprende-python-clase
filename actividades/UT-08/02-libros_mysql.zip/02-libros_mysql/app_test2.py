import logging

from db.libros_dao import LibrosDao
from db.editoriales_dao import EditorialesDao
from db.autores_dao import AutoresDao

logging.basicConfig(level=logging.INFO)

print("\n=== TEST DE LECTURA DE DATOS ===\n")

libros_dao = LibrosDao()
editoriales_dao = EditorialesDao()
autores_dao = AutoresDao()

# ======================================
# LIBROS
# ======================================
print("LIBROS:")
libros = libros_dao.get_all()

if not libros:
    print("No hay libros en la BD")
else:
    for l in libros:
        print(l)


# ======================================
# EDITORIALES
# ======================================
print("\nEDITORIALES:")
editoriales = editoriales_dao.get_all()

if not editoriales:
    print("No hay editoriales")
else:
    for e in editoriales:
        print(e)


# ======================================
# AUTORES
# ======================================
print("\nAUTORES:")
autores = autores_dao.get_all()

if not autores:
    print("No hay autores")
else:
    for a in autores:
        print(a)


# ======================================
# RELACIONES (LIBRO -> AUTORES)
# ======================================
print("\nRELACIONES LIBRO - AUTORES:")

if libros:
    for libro in libros:
        print(f"\nLibro: {libro['titulo']}")

        autores_libro = autores_dao.get_by_libro(libro['id'])

        if not autores_libro:
            print("  (Sin autores)")
        else:
            for a in autores_libro:
                print(f"  - {a['nombre']}")

print("\n=== FIN TEST ===")