import logging

from db.database import Database
from db.libros_dao import LibrosDao
from db.editoriales_dao import EditorialesDao
from db.autores_dao import AutoresDao

# Configuración básica de logging (puede personalizar el formato y nivel)
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s [%(levelname)-8s] [%(name)s] %(message)s',
    filename='errores.log',  # si quieres guardar en archivo
    filemode='a',  # append al archivo
    encoding='utf-8'
)

logger = logging.getLogger("APP")
logger.debug("Aplicación iniciada")

#db = Database.connect()

libros_dao = LibrosDao()
editoriales_dao = EditorialesDao()
autores_dao = AutoresDao()

editorial_id = editoriales_dao.add(
    {"nombre": "Planeta"})

id = libros_dao.add(
    {"isbn": "978-00-00-000001",
     "titulo": "El Quijote",
     "fecha_publicacion": 1600,
     "editorial_id": editorial_id
     }
)

autor1_id = autores_dao.add({"nombre": "Pepito","libro_id": id})
autor1_id = autores_dao.add({"nombre": "Luisita","libro_id": id})


if id > 0:
    print("El id es: ", id)
    libro = libros_dao.get(id)
    print(libro)
else:
    print("No se pudo añadir el libro")

print(libros_dao.get_all())

print(editoriales_dao.get_all())

print(autores_dao.get_all())

Database.close()








