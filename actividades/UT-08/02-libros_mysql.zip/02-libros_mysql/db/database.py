# database.py
import logging
import mysql.connector
import json


class Database:
    logger = logging.getLogger(__name__)
    _conn  = None
    _config = None

    @classmethod
    def _load_config(cls):
        if cls._config is None:
            cls.logger.info("Cargando configuración desde config_db.json")

            try:
                with open("db/config_db.json", "r", encoding="utf-8") as f:
                    cls._config = json.load(f)
            except Exception as e:
                cls.logger.critical(f"Error al cargar config_db.json: {e}")
                raise

    def __new__(cls):
        raise TypeError("Database es un singleton. No se puede instanciar Database")

    @classmethod
    def connect(cls):
        try:
            cls._load_config()

            if cls._conn is None:
                cls.logger.info("Creando nueva conexión a MySQL")
                cls._conn = mysql.connector.connect(**cls._config)

            elif not cls._conn.is_connected():
                cls.logger.warning("Conexión perdida. Recreando conexión...")
                try:
                    cls._conn.close()
                except Exception:
                    pass

                cls._conn = mysql.connector.connect(**cls._config)

            return cls._conn

        except Exception as e:
            cls.logger.critical(f"Error al conectar a la base de datos: {e}")
            cls._conn = None
            raise

    @classmethod
    def close(cls):
        if cls._conn:
            cls._conn.close()
            cls._conn = None

